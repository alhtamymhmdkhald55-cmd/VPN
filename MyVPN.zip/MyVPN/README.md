# My VPN (Android + WireGuard)

## الخطوات
1. أنشئ سيرفر Ubuntu (VPS) وشغّل `server/setup_wireguard_server.sh` بصلاحية root.
2. انسخ محتوى `client.conf` الذي يطبعه السكربت.
3. افتح مجلد المشروع في Android Studio ثم Run.
4. الصق الإعدادات داخل التطبيق واضغط "اتصال".

ملاحظة: التطبيق هو العميل فقط، والـ VPN يحتاج سيرفر خاص بك.
