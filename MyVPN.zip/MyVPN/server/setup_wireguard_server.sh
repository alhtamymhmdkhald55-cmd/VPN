#!/bin/bash
# شغّله على سيرفر Ubuntu كمستخدم root:  sudo bash setup_wireguard_server.sh
set -e
IFACE=$(ip route | awk '/default/ {print $5; exit}')
PUBIP=$(curl -s ifconfig.me)

apt update && apt install -y wireguard qrencode
cd /etc/wireguard
umask 077
wg genkey | tee server.key | wg pubkey > server.pub
wg genkey | tee client.key | wg pubkey > client.pub

cat > wg0.conf <<CONF
[Interface]
Address = 10.8.0.1/24
ListenPort = 51820
PrivateKey = $(cat server.key)
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o $IFACE -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o $IFACE -j MASQUERADE

[Peer]
PublicKey = $(cat client.pub)
AllowedIPs = 10.8.0.2/32
CONF

echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-wg.conf
sysctl --system
ufw allow 51820/udp 2>/dev/null || true
systemctl enable --now wg-quick@wg0

cat > client.conf <<CONF
[Interface]
PrivateKey = $(cat client.key)
Address = 10.8.0.2/32
DNS = 1.1.1.1

[Peer]
PublicKey = $(cat server.pub)
Endpoint = $PUBIP:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
CONF

echo "=============== انسخ هذا الملف داخل التطبيق ==============="
cat client.conf
