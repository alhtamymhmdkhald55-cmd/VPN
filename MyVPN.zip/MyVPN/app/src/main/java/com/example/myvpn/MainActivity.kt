package com.example.myvpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

class MainActivity : AppCompatActivity() {

    private lateinit var backend: GoBackend
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var toggle: Button
    private var connected = false

    private val tunnel = object : Tunnel {
        override fun getName() = "myvpn"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread { updateUi(newState == Tunnel.State.UP) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        backend = GoBackend(applicationContext)
        status = findViewById(R.id.status)
        input = findViewById(R.id.configInput)
        toggle = findViewById(R.id.toggle)

        val prefs = getSharedPreferences("vpn", MODE_PRIVATE)
        input.setText(prefs.getString("config", ""))

        toggle.setOnClickListener {
            prefs.edit().putString("config", input.text.toString()).apply()
            if (connected) setTunnelState(Tunnel.State.DOWN) else requestPermissionThenConnect()
        }
    }

    private fun requestPermissionThenConnect() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, 100)
        else setTunnelState(Tunnel.State.UP)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) setTunnelState(Tunnel.State.UP)
    }

    private fun setTunnelState(state: Tunnel.State) {
        Thread {
            try {
                val config = Config.parse(BufferedReader(StringReader(input.text.toString())))
                backend.setState(tunnel, state, config)
                runOnUiThread { updateUi(state == Tunnel.State.UP) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun updateUi(isUp: Boolean) {
        connected = isUp
        status.text = if (isUp) "متصل ✅" else "غير متصل"
        toggle.text = if (isUp) "قطع الاتصال" else "اتصال"
    }
}
